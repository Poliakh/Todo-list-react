import React from 'react';
import ReactDOM from 'react-dom';

import './style.css'

const App = () => {
	return (
		<div className="todo-app">
			<div className="app-header d-flex">
				<h1>Todo list</h1>
				<h2>2 more to do, 1</h2>
			</div>
			<div className="top-panel d-flex">
				<input type="text" className="form-control search-input" placeholder="type to search" ></input>

				<div className="btn-group">
					<button type="button"
						className="btn btn-outline-secondary">All</button>
					<button type="button"
						className="btn btn-info">Active</button>
					<button type="button"
						className="btn btn-outline-secondary">Done</button>
				</div>
			</div>
			<ul className="list-group todo-list">
				<li className="list-group-item">
					<span className="todo-list-item">
						<span className="todo-list-item-label ">Drink Coffee</span>
						<button type="button" className="btn btn-outline-success btn-sm float-right"><i className="fa fa-exclamation"></i></button>
						<button type="button" className="btn btn-outline-danger btn-sm float-right"><i className="fa fa-trash-o"></i></button></span>
				</li>
				<li className="list-group-item">
					<span className="todo-list-item">
						<span className="todo-list-item-label ">Have a lunch</span>
						<button type="button" className="btn btn-outline-success btn-sm float-right">
							<i className="fa fa-exclamation"></i
							></button>
						<button type="button" className="btn btn-outline-danger btn-sm float-right">
							<i className="fa fa-trash-o"></i>
						</button>
					</span>
				</li>
			</ul>
			<form className="item-add-form d-flex">
				<input className="form-control" placeholder="What needs to be done" />
				<button className="btn btn-outline-secondary">Add Item</button>
			</form>
		</div>

	)
}
ReactDOM.render(<App />, document.getElementById('root'))

